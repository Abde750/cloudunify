package com.cloudunify.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
