/* ═══════════════════════════════════════════════════════════════
   CloudUnify Pro — app.js
   Google Drive API v3  +  Microsoft Graph API (OneDrive)  +  Dropbox API v2
   Multi-compte : chaque service est une LISTE de comptes, pas un singleton.
═══════════════════════════════════════════════════════════════ */

/* ─── State ─────────────────────────────────────────────────── */
// Chaque service est désormais un tableau de comptes connectés.
// Compte = { id, svc, label, token, files, user, quota, refreshToken }
const STATE = { gdrive: [], onedrive: [], dropbox: [] };

let acctSeq = 0;
function makeAccount(svc, label) {
  return { id: svc + '_' + (++acctSeq), svc, label: label || null, token: null, files: [], user: null, quota: null };
}
function allAccounts() { return [...STATE.gdrive, ...STATE.onedrive, ...STATE.dropbox]; }
function findAccount(svc, id) { return (STATE[svc] || []).find(a => a.id === id); }
function findAccountByFile(f) { return findAccount(f._svc, f._acct); }
function accountLabel(a) { return (a && (a.label || a.user)) || 'Compte'; }
function connectedServices() { return ['gdrive', 'onedrive', 'dropbox'].filter(s => STATE[s].length > 0); }
function removeAccount(acct) {
  const arr = STATE[acct.svc];
  const i = arr.indexOf(acct);
  if (i > -1) arr.splice(i, 1);
  renderSidebarAccounts();
}

/* Normalizes the 3 different quota shapes (Google uses strings + {usage,limit},
   Microsoft/Dropbox use numbers + {used,total}) into one common {used,total}. */
function acctUsedTotal(a) {
  if (!a.quota) return null;
  if (a.svc === 'gdrive') return { used: parseInt(a.quota.usage) || 0, total: parseInt(a.quota.limit) || 1 };
  return { used: a.quota.used || 0, total: a.quota.total || 1 };
}

/* Central place for per-service display metadata — add iCloud here later */
const SVC_META = {
  gdrive:   { label: 'Google Drive', short: 'GD', color: '#34a853', bg: '#e8f5e9' },
  onedrive: { label: 'OneDrive',     short: 'OD', color: '#0078d4', bg: '#e3f2fd' },
  dropbox:  { label: 'Dropbox',      short: 'DB', color: '#0061ff', bg: '#e8edff' },
};
function svcLabel(svc) { return SVC_META[svc]?.label || svc; }
function svcShort(svc) { return SVC_META[svc]?.short || '?'; }
function svcColor(svc) { return SVC_META[svc]?.color || '#888'; }
function svcBg(svc)    { return SVC_META[svc]?.bg    || '#eee'; }

let allFiles      = [];
let displayFiles  = [];
let selectedFile  = null;
let currentTab    = 'all';
let currentNav    = 'all';
let currentChip   = 'all';
let sortField     = 'date';
let sortAsc       = false;

/* ─── Mime → Icon ────────────────────────────────────────────── */
const MIME_ICONS = {
  'application/pdf': '📕',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '📝',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '📗',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': '📙',
  'application/vnd.google-apps.document': '📝',
  'application/vnd.google-apps.spreadsheet': '📗',
  'application/vnd.google-apps.presentation': '📙',
  'application/vnd.google-apps.folder': '📁',
  'application/vnd.google-apps.form': '📋',
  'image/jpeg': '🖼️', 'image/png': '🖼️', 'image/gif': '🖼️',
  'image/webp': '🖼️', 'image/svg+xml': '🖼️', 'image/heic': '🖼️',
  'video/mp4': '🎬', 'video/quicktime': '🎬', 'video/x-msvideo': '🎬',
  'audio/mpeg': '🎵', 'audio/ogg': '🎵', 'audio/wav': '🎵', 'audio/mp4': '🎵',
  'application/zip': '📦', 'application/x-zip-compressed': '📦',
  'application/x-rar-compressed': '📦', 'application/x-7z-compressed': '📦',
  'application/x-tar': '📦',
  'text/plain': '📄', 'text/html': '🌐', 'text/css': '🎨',
  'application/javascript': '⚙️', 'application/json': '⚙️',
  'application/x-python-code': '🐍', 'text/x-python': '🐍',
  'default': '📄',
};
function getIcon(mime) { return MIME_ICONS[mime] || MIME_ICONS.default; }

/* Dropbox's file listing has no mimeType field — infer one from the
   extension so the same icon table and doc/img/video filters still work. */
function guessMimeFromName(name) {
  const ext = (name.split('.').pop() || '').toLowerCase();
  const map = {
    pdf:'application/pdf',
    doc:'application/msword', docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xls:'application/vnd.ms-excel', xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ppt:'application/vnd.ms-powerpoint', pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    jpg:'image/jpeg', jpeg:'image/jpeg', png:'image/png', gif:'image/gif', webp:'image/webp', svg:'image/svg+xml', heic:'image/heic',
    mp4:'video/mp4', mov:'video/quicktime', avi:'video/x-msvideo',
    mp3:'audio/mpeg', wav:'audio/wav', ogg:'audio/ogg', m4a:'audio/mp4',
    zip:'application/zip', rar:'application/x-rar-compressed', '7z':'application/x-7z-compressed', tar:'application/x-tar',
    txt:'text/plain', csv:'text/plain', html:'text/html', css:'text/css',
    js:'application/javascript', json:'application/json', py:'text/x-python',
  };
  return map[ext] || 'application/octet-stream';
}

/* ─── Helpers ────────────────────────────────────────────────── */
function fmtSize(bytes) {
  if (!bytes || bytes === 0) return '—';
  const b = parseInt(bytes) || 0;
  if (b < 1024) return b + ' o';
  if (b < 1048576) return Math.round(b / 1024) + ' Ko';
  if (b < 1073741824) return (b / 1048576).toFixed(1) + ' Mo';
  return (b / 1073741824).toFixed(2) + ' Go';
}

function fmtDate(d) {
  if (!d) return '—';
  const dt = new Date(d);
  if (isNaN(dt)) return '—';
  const now = new Date();
  const diff = (now - dt) / 1000;
  if (diff < 60) return 'À l\'instant';
  if (diff < 3600) return Math.round(diff / 60) + ' min';
  if (diff < 86400) return Math.round(diff / 3600) + 'h';
  if (diff < 604800) return Math.round(diff / 86400) + 'j';
  return dt.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}

function fmtDateFull(d) {
  if (!d) return '—';
  const dt = new Date(d);
  if (isNaN(dt)) return '—';
  return dt.toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function toast(msg, duration = 3000) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

function openModal(id) {
  document.getElementById(id).classList.add('open');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  const bar = document.querySelector(`#${id} .progress-fill`);
  if (bar) bar.style.width = '0%';
  const prog = document.querySelector(`#${id} [id$="-progress"]`);
  if (prog) prog.style.display = 'none';
}

function openExternal(url) {
  if (window.electronAPI?.openExternal) {
    window.electronAPI.openExternal(url);
  } else {
    window.open(url, '_blank');
  }
}

/* Opens the connect modal pre-switched to a given service tab — used by
   the "+ Ajouter un compte" link under each service group in the sidebar. */
function openConnectFor(tabCode) {
  openModal('modal-connect');
  const btn = document.querySelector(`.stab[data-tab="${tabCode}"]`);
  if (btn) switchServiceTab(btn, tabCode);
}

/* ─── Google Drive Integration ─────────────────────────────── */
async function connectGDrive() {
  const token        = document.getElementById('gd-token').value.trim();
  const clientId      = document.getElementById('gd-client-id').value.trim();
  const clientSecret  = document.getElementById('gd-client-secret').value.trim();
  const label         = document.getElementById('gd-label').value.trim();
  if (!token && !clientId) { toast('⚠ Entrez un Client ID ou un Access Token'); return; }
  if (!token && clientId && !clientSecret) { toast('⚠ Google exige aussi un Client Secret (voir étape 4)'); return; }
  closeModal('modal-connect');
  document.getElementById('gd-label').value = '';

  const acct = makeAccount('gdrive', label);
  STATE.gdrive.push(acct);

  if (token) {
    await loadGDriveWithToken(acct, token);
  } else if (window.electronAPI?.startOAuth) {
    toast('🔐 Ouverture de votre navigateur — connectez-vous à Google, puis revenez ici.', 8000);
    const result = await window.electronAPI.startOAuth('gdrive', clientId, clientSecret);
    if (result?.token) await loadGDriveWithToken(acct, result.token);
    else { toast('❌ ' + (result?.error || 'Authentification annulée'), 6000); removeAccount(acct); }
  } else {
    toast('ℹ Mode navigateur : utilisez un Access Token direct (l\'app desktop est requise pour l\'OAuth complet)');
    removeAccount(acct);
  }
}

async function loadGDriveWithToken(acct, token) {
  toast('⏳ Connexion à Google Drive…');
  acct.token = token;
  try {
    const r = await fetch(
      'https://www.googleapis.com/drive/v3/about?fields=user,storageQuota',
      { headers: { Authorization: 'Bearer ' + token } }
    );
    if (!r.ok) throw new Error('Token invalide (status ' + r.status + ')');
    const info = await r.json();
    acct.user = info.user?.displayName || info.user?.emailAddress || 'Utilisateur Drive';
    if (!acct.label) acct.label = acct.user;
    acct.quota = info.storageQuota;

    await fetchGDriveFiles(acct);
    setAccountConnected(acct);
  } catch (e) {
    toast('❌ Google Drive : ' + e.message);
    removeAccount(acct);
  }
}

async function fetchGDriveFiles(acct, pageToken) {
  let url = 'https://www.googleapis.com/drive/v3/files'
    + '?pageSize=100'
    + '&fields=nextPageToken,files(id,name,mimeType,size,modifiedTime,owners,webViewLink,shared,parents,trashed)'
    + '&orderBy=modifiedTime+desc'
    + '&q=trashed%3Dfalse';
  if (pageToken) url += '&pageToken=' + pageToken;

  const r = await fetch(url, { headers: { Authorization: 'Bearer ' + acct.token } });
  const d = await r.json();
  const mapped = (d.files || []).map(f => ({
    id: f.id, name: f.name, mimeType: f.mimeType, size: f.size, modifiedTime: f.modifiedTime,
    owners: f.owners, webViewLink: f.webViewLink, shared: f.shared,
    _svc: 'gdrive', _acct: acct.id, _icon: getIcon(f.mimeType),
  }));
  acct.files = [...(pageToken ? acct.files : []), ...mapped];

  if (d.nextPageToken && acct.files.length < 300) {
    await fetchGDriveFiles(acct, d.nextPageToken);
  }
}

/* Demo mode */
function loadGDriveMock() {
  const label = document.getElementById('gd-label').value.trim();
  const acct = makeAccount('gdrive', label);
  acct.user  = 'Jean Dupont (démo)';
  if (!acct.label) acct.label = acct.user;
  acct.quota = { usage: '9663676416', limit: '16106127360' };
  acct.token = 'DEMO';
  acct.files = [
    { id:'gd1', name:'Rapport annuel 2024.pdf',      mimeType:'application/pdf',                                                              size:'4294967', modifiedTime:'2024-12-10T14:30:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'gdrive', _acct:acct.id, _icon:'📕' },
    { id:'gd2', name:'Budget Q4 2024.xlsx',          mimeType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',            size:'1887437', modifiedTime:'2024-12-09T10:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:true,  _svc:'gdrive', _acct:acct.id, _icon:'📗' },
    { id:'gd3', name:'Présentation clients.pptx',    mimeType:'application/vnd.openxmlformats-officedocument.presentationml.presentation',    size:'12437810',modifiedTime:'2024-12-08T16:45:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:true,  _svc:'gdrive', _acct:acct.id, _icon:'📙' },
    { id:'gd4', name:'Notes réunion 05-12.docx',     mimeType:'application/vnd.google-apps.document',                                        size:null,      modifiedTime:'2024-12-05T09:15:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'gdrive', _acct:acct.id, _icon:'📝' },
    { id:'gd5', name:'Photo vacances été.jpg',        mimeType:'image/jpeg',                                                                   size:'3145728', modifiedTime:'2024-12-03T18:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'gdrive', _acct:acct.id, _icon:'🖼️' },
    { id:'gd6', name:'Archive code source.zip',       mimeType:'application/zip',                                                              size:'52428800',modifiedTime:'2024-12-01T11:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'gdrive', _acct:acct.id, _icon:'📦' },
  ];
  STATE.gdrive.push(acct);
  closeModal('modal-connect');
  document.getElementById('gd-label').value = '';
  setAccountConnected(acct);
}

/* ─── OneDrive Integration ──────────────────────────────────── */
async function connectOneDrive() {
  const token    = document.getElementById('od-token').value.trim();
  const clientId = document.getElementById('od-client-id').value.trim();
  const label    = document.getElementById('od-label').value.trim();
  if (!token && !clientId) { toast('⚠ Entrez un Client ID ou un Access Token'); return; }
  closeModal('modal-connect');
  document.getElementById('od-label').value = '';

  const acct = makeAccount('onedrive', label);
  STATE.onedrive.push(acct);

  if (token) {
    await loadOneDriveWithToken(acct, token);
  } else if (window.electronAPI?.startOAuth) {
    toast('🔐 Ouverture de votre navigateur — connectez-vous à Microsoft, puis revenez ici.', 8000);
    const result = await window.electronAPI.startOAuth('onedrive', clientId);
    if (result?.token) await loadOneDriveWithToken(acct, result.token);
    else { toast('❌ ' + (result?.error || 'Authentification annulée'), 6000); removeAccount(acct); }
  } else {
    toast('ℹ Mode navigateur : utilisez un Access Token direct (l\'app desktop est requise pour l\'OAuth complet)');
    removeAccount(acct);
  }
}

async function loadOneDriveWithToken(acct, token) {
  toast('⏳ Connexion à OneDrive…');
  acct.token = token;
  try {
    const r = await fetch('https://graph.microsoft.com/v1.0/me/drive',
      { headers: { Authorization: 'Bearer ' + token } });
    if (!r.ok) throw new Error('Token invalide (status ' + r.status + ')');
    const driveInfo = await r.json();
    acct.quota = driveInfo.quota;

    const r2 = await fetch('https://graph.microsoft.com/v1.0/me',
      { headers: { Authorization: 'Bearer ' + token } });
    const user = await r2.json();
    acct.user = user.displayName || user.userPrincipalName || 'Utilisateur OneDrive';
    if (!acct.label) acct.label = acct.user;

    await fetchOneDriveFiles(acct);
    setAccountConnected(acct);
  } catch (e) {
    toast('❌ OneDrive : ' + e.message);
    removeAccount(acct);
  }
}

async function fetchOneDriveFiles(acct, nextLink) {
  const url = nextLink ||
    'https://graph.microsoft.com/v1.0/me/drive/recent'
    + '?$top=100'
    + '&$select=id,name,file,size,lastModifiedDateTime,createdBy,webUrl,shared,folder';

  const r = await fetch(url, { headers: { Authorization: 'Bearer ' + acct.token } });
  const d = await r.json();
  const mapped = (d.value || []).map(f => ({
    id: f.id, name: f.name,
    mimeType: f.file?.mimeType || (f.folder ? 'application/vnd.google-apps.folder' : 'application/octet-stream'),
    size: f.size?.toString(), modifiedTime: f.lastModifiedDateTime,
    owners: [{ displayName: f.createdBy?.user?.displayName || acct.user }],
    webViewLink: f.webUrl, shared: !!f.shared,
    _svc: 'onedrive', _acct: acct.id, _icon: getIcon(f.file?.mimeType || ''),
  }));
  acct.files = [...(nextLink ? acct.files : []), ...mapped];

  if (d['@odata.nextLink'] && acct.files.length < 300) {
    await fetchOneDriveFiles(acct, d['@odata.nextLink']);
  }
}

function loadOneDriveMock() {
  const label = document.getElementById('od-label').value.trim();
  const acct = makeAccount('onedrive', label);
  acct.user  = 'Jean Dupont (démo)';
  if (!acct.label) acct.label = acct.user;
  acct.quota = { used: 34359738368, total: 107374182400 };
  acct.token = 'DEMO';
  acct.files = [
    { id:'od1', name:'Contrat fournisseur 2024.pdf', mimeType:'application/pdf',                                                           size:'890000',    modifiedTime:'2024-12-11T08:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'onedrive', _acct:acct.id, _icon:'📄' },
    { id:'od2', name:'Tableur financier S2.xlsx',    mimeType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',         size:'2345678',   modifiedTime:'2024-12-10T16:30:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:true,  _svc:'onedrive', _acct:acct.id, _icon:'📗' },
    { id:'od3', name:'Archive projets 2023.zip',     mimeType:'application/zip',                                                          size:'2415919104',modifiedTime:'2024-12-09T12:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'onedrive', _acct:acct.id, _icon:'📦' },
    { id:'od4', name:'Vidéo présentation corp.mp4',  mimeType:'video/mp4',                                                                size:'847249408', modifiedTime:'2024-12-08T10:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:true,  _svc:'onedrive', _acct:acct.id, _icon:'🎬' },
    { id:'od5', name:'Photo équipe 2024.png',         mimeType:'image/png',                                                                size:'4567890',   modifiedTime:'2024-12-06T14:20:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'onedrive', _acct:acct.id, _icon:'🖼️' },
    { id:'od6', name:'Notes de projet Alpha.docx',   mimeType:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',  size:'234000',    modifiedTime:'2024-12-04T09:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'onedrive', _acct:acct.id, _icon:'📝' },
  ];
  STATE.onedrive.push(acct);
  closeModal('modal-connect');
  document.getElementById('od-label').value = '';
  setAccountConnected(acct);
}

/* ─── Dropbox Integration ─────────────────────────────────────
   Dropbox's PKCE flow needs NO client secret at all — simpler
   than Google. Files are addressed by *path*, not just an id,
   so we keep an extra `_path` field for content/delete calls. */
async function connectDropbox() {
  const token    = document.getElementById('db-token').value.trim();
  const clientId = document.getElementById('db-client-id').value.trim();
  const label    = document.getElementById('db-label').value.trim();
  if (!token && !clientId) { toast('⚠ Entrez une App key ou un Access Token'); return; }
  closeModal('modal-connect');
  document.getElementById('db-label').value = '';

  const acct = makeAccount('dropbox', label);
  STATE.dropbox.push(acct);

  if (token) {
    await loadDropboxWithToken(acct, token);
  } else if (window.electronAPI?.startOAuth) {
    toast('🔐 Ouverture de votre navigateur — connectez-vous à Dropbox, puis revenez ici.', 8000);
    const result = await window.electronAPI.startOAuth('dropbox', clientId);
    if (result?.token) await loadDropboxWithToken(acct, result.token);
    else { toast('❌ ' + (result?.error || 'Authentification annulée'), 6000); removeAccount(acct); }
  } else {
    toast('ℹ Mode navigateur : utilisez un Access Token direct (l\'app desktop est requise pour l\'OAuth complet)');
    removeAccount(acct);
  }
}

async function loadDropboxWithToken(acct, token) {
  toast('⏳ Connexion à Dropbox…');
  acct.token = token;
  try {
    const r = await fetch('https://api.dropboxapi.com/2/users/get_current_account', {
      method: 'POST', headers: { Authorization: 'Bearer ' + token },
    });
    if (!r.ok) throw new Error('Token invalide (status ' + r.status + ')');
    const info = await r.json();
    acct.user = info.name?.display_name || 'Utilisateur Dropbox';
    if (!acct.label) acct.label = acct.user;

    const rq = await fetch('https://api.dropboxapi.com/2/users/get_space_usage', {
      method: 'POST', headers: { Authorization: 'Bearer ' + token },
    });
    const quota = await rq.json();
    acct.quota = { used: quota.used || 0, total: quota.allocation?.allocated || 21474836480 };

    await fetchDropboxFiles(acct);
    setAccountConnected(acct);
  } catch (e) {
    toast('❌ Dropbox : ' + e.message);
    removeAccount(acct);
  }
}

async function fetchDropboxFiles(acct, cursor) {
  const url = cursor
    ? 'https://api.dropboxapi.com/2/files/list_folder/continue'
    : 'https://api.dropboxapi.com/2/files/list_folder';
  const body = cursor ? { cursor } : { path: '', recursive: false, limit: 100, include_non_downloadable_files: false };

  const r = await fetch(url, {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + acct.token, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const d = await r.json();
  const mapped = (d.entries || [])
    .filter(e => e['.tag'] === 'file' || e['.tag'] === 'folder')
    .map(e => {
      const isFolder = e['.tag'] === 'folder';
      const mime = isFolder ? 'application/vnd.google-apps.folder' : guessMimeFromName(e.name);
      return {
        id: e.id, name: e.name, mimeType: mime, size: e.size?.toString(),
        modifiedTime: e.server_modified || e.client_modified,
        owners: [{ displayName: acct.user }], webViewLink: null, shared: !!e.sharing_info,
        _svc: 'dropbox', _acct: acct.id, _icon: isFolder ? '📁' : getIcon(mime),
        _path: e.path_lower || e.path_display,
      };
    });
  acct.files = [...(cursor ? acct.files : []), ...mapped];

  if (d.has_more && acct.files.length < 300) {
    await fetchDropboxFiles(acct, d.cursor);
  }
}

function loadDropboxMock() {
  const label = document.getElementById('db-label').value.trim();
  const acct = makeAccount('dropbox', label);
  acct.user  = 'Jean Dupont (démo)';
  if (!acct.label) acct.label = acct.user;
  acct.quota = { used: 6979321856, total: 21474836480 };
  acct.token = 'DEMO';
  acct.files = [
    { id:'db1', name:'Facture fournisseur.pdf',   mimeType:'application/pdf',        size:'512000',   modifiedTime:'2024-12-11T09:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'dropbox', _acct:acct.id, _icon:'📕', _path:'/facture fournisseur.pdf' },
    { id:'db2', name:'Roadmap produit.xlsx',      mimeType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', size:'988000', modifiedTime:'2024-12-10T15:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:true, _svc:'dropbox', _acct:acct.id, _icon:'📗', _path:'/roadmap produit.xlsx' },
    { id:'db4', name:'Logo entreprise.svg',       mimeType:'image/svg+xml',          size:'45000',    modifiedTime:'2024-12-07T13:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'dropbox', _acct:acct.id, _icon:'🖼️', _path:'/logo entreprise.svg' },
    { id:'db5', name:'Enregistrement réunion.mp3',mimeType:'audio/mpeg',             size:'15728640', modifiedTime:'2024-12-02T10:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:false, _svc:'dropbox', _acct:acct.id, _icon:'🎵', _path:'/enregistrement reunion.mp3' },
    { id:'db6', name:'Contrat NDA.docx',          mimeType:'application/vnd.openxmlformats-officedocument.wordprocessingml.document', size:'128000', modifiedTime:'2024-11-29T08:00:00Z', owners:[{displayName:acct.user}], webViewLink:'#', shared:true, _svc:'dropbox', _acct:acct.id, _icon:'📝', _path:'/contrat nda.docx' },
  ];
  STATE.dropbox.push(acct);
  closeModal('modal-connect');
  document.getElementById('db-label').value = '';
  setAccountConnected(acct);
}

/* ─── Connection lifecycle (shared across all 3 services) ────── */
function setAccountConnected(acct) {
  updateConnCount();
  refreshAllFiles();
  renderSidebarAccounts();
  toast('✓ ' + svcLabel(acct.svc) + ' connecté (' + accountLabel(acct) + ') — ' + acct.files.length + ' fichiers');
}

function disconnectAccount(svc, id) {
  const arr = STATE[svc];
  const idx = arr.findIndex(a => a.id === id);
  if (idx === -1) return;
  const label = accountLabel(arr[idx]);
  arr.splice(idx, 1);
  if (currentNav === id) currentNav = 'all';
  updateConnCount();
  refreshAllFiles();
  renderSidebarAccounts();
  toast(svcLabel(svc) + ' déconnecté (' + label + ')');
}

/* ─── Sidebar: accounts list + storage mini-bars (fully dynamic) ── */
function renderSidebarAccounts() {
  ['gdrive', 'onedrive', 'dropbox'].forEach(svc => {
    const wrap = document.getElementById('accts-' + svc);
    const cnt  = document.getElementById('cnt-' + svc);
    if (!wrap) return;
    const accounts = STATE[svc];
    cnt.textContent = accounts.length || '';
    wrap.innerHTML = accounts.map(a => `
      <div class="acct-row ${currentNav === a.id ? 'active' : ''}" onclick="setNav(this,'${a.id}')">
        <span class="acct-dot" style="background:${svcColor(svc)}"></span>
        <span class="acct-label" title="${accountLabel(a)}">${accountLabel(a)}</span>
        <span class="acct-x" onclick="event.stopPropagation();disconnectAccount('${svc}','${a.id}')" title="Déconnecter ce compte">✕</span>
      </div>`).join('');
  });
  renderStorageMini();
}

function renderStorageMini() {
  const wrap = document.getElementById('storage-mini-list');
  const accts = allAccounts();
  if (!accts.length) {
    wrap.innerHTML = '<div id="smini-empty">Aucun compte actif</div>';
    return;
  }
  wrap.innerHTML = accts.map(a => {
    const ut  = acctUsedTotal(a);
    const pct = ut ? Math.round(ut.used / ut.total * 100) : 0;
    return `
    <div class="smini-row">
      <span title="${svcLabel(a.svc)} — ${accountLabel(a)}">${svcShort(a.svc)} · ${accountLabel(a)}</span>
      <div class="smini-bar"><div class="smini-fill" style="width:${pct}%;background:${svcColor(a.svc)}"></div></div>
      <span>${pct}%</span>
    </div>`;
  }).join('');
}

/* ─── File Display ───────────────────────────────────────────── */
function updateConnCount() {
  const n = allAccounts().length;
  document.getElementById('conn-count').textContent =
    n + ' compte' + (n > 1 ? 's' : '') + ' connecté' + (n > 1 ? 's' : '');

  const dot = document.getElementById('status-dot');
  const txt = document.getElementById('status-text');
  if (n === 0) { dot.style.background = '#ccc'; txt.textContent = 'Aucun compte actif'; }
  else         { dot.style.background = '#22c55e'; txt.textContent = n + ' compte' + (n > 1 ? 's' : '') + ' actif' + (n > 1 ? 's' : ''); }
}

function refreshAllFiles() {
  allFiles = allAccounts().flatMap(a => a.files);
  allFiles.sort((a, b) => new Date(b.modifiedTime) - new Date(a.modifiedTime));
  applyFiltersAndRender();
  clearSelection();
}

function applyFiltersAndRender() {
  let f = [...allFiles];

  // Nav filter — either a category, a whole service (all its accounts), or one specific account id
  if      (currentNav === 'gdrive')   f = f.filter(x => x._svc === 'gdrive');
  else if (currentNav === 'onedrive') f = f.filter(x => x._svc === 'onedrive');
  else if (currentNav === 'dropbox')  f = f.filter(x => x._svc === 'dropbox');
  else if (currentNav === 'recent')   f = f.filter(x => (new Date() - new Date(x.modifiedTime)) < 7 * 86400000);
  else if (currentNav === 'shared')   f = f.filter(x => x.shared);
  else if (currentNav === 'starred')  f = f.filter((_, i) => i % 3 === 0);
  else if (currentNav !== 'all')      f = f.filter(x => x._acct === currentNav); // specific account

  // Tab filter
  const DOC_TYPES = ['application/pdf','application/vnd.openxmlformats','application/vnd.google-apps.document','application/vnd.google-apps.spreadsheet','application/vnd.google-apps.presentation'];
  if      (currentTab === 'doc')   f = f.filter(x => DOC_TYPES.some(t => x.mimeType.startsWith(t)));
  else if (currentTab === 'img')   f = f.filter(x => x.mimeType.startsWith('image/'));
  else if (currentTab === 'vid')   f = f.filter(x => x.mimeType.startsWith('video/'));
  else if (currentTab === 'other') f = f.filter(x => !x.mimeType.startsWith('image/') && !x.mimeType.startsWith('video/') && !DOC_TYPES.some(t => x.mimeType.startsWith(t)));

  // Chip filter
  if      (currentChip === 'recent') f = f.filter(x => (new Date() - new Date(x.modifiedTime)) < 7 * 86400000);
  else if (currentChip === 'shared') f = f.filter(x => x.shared);
  else if (currentChip === 'large')  f = f.filter(x => parseInt(x.size || 0) > 104857600);
  else if (currentChip === 'dups') {
    const names = f.map(x => x.name.toLowerCase());
    f = f.filter(x => names.indexOf(x.name.toLowerCase()) !== names.lastIndexOf(x.name.toLowerCase()));
  }

  // Search
  const q = document.getElementById('search-input').value.trim().toLowerCase();
  if (q) f = f.filter(x => x.name.toLowerCase().includes(q) || svcLabel(x._svc).toLowerCase().includes(q));

  // Sort
  f.sort((a, b) => {
    let va, vb;
    if (sortField === 'name') { va = a.name.toLowerCase(); vb = b.name.toLowerCase(); }
    else if (sortField === 'size') { va = parseInt(a.size || 0); vb = parseInt(b.size || 0); }
    else { va = new Date(a.modifiedTime); vb = new Date(b.modifiedTime); }
    return sortAsc ? (va > vb ? 1 : -1) : (va < vb ? 1 : -1);
  });

  displayFiles = f;
  renderFiles();
}

function renderFiles() {
  const hasAny = allFiles.length > 0;
  document.getElementById('empty-state').style.display = hasAny ? 'none' : 'block';
  document.getElementById('list-view').style.display = hasAny ? 'block' : 'none';

  document.getElementById('status-count').textContent =
    displayFiles.length + ' fichier' + (displayFiles.length > 1 ? 's' : '');

  renderList();
}

function renderList() {
  const rows = document.getElementById('list-rows');
  rows.innerHTML = displayFiles.map((f, i) => {
    const acct = findAccountByFile(f);
    const acctLbl = acct ? accountLabel(acct) : '';
    return `
    <div class="list-row" id="fl-${i}" onclick="selectFile(${i})">
      <span class="lr-icon">${f._icon}</span>
      <div class="lr-main">
        <div class="lr-name">${f.name}</div>
        <div class="lr-sub">
          <span style="color:${svcColor(f._svc)};font-weight:600">${svcShort(f._svc)}</span>
          <span>${acctLbl ? '· ' + acctLbl + ' · ' : ''}${fmtSize(parseInt(f.size)||0)} · ${fmtDate(f.modifiedTime)}</span>
        </div>
      </div>
      <span class="lr-shared">${f.shared ? '👥' : ''}</span>
    </div>`;
  }).join('');
}

/* ─── File Selection ─────────────────────────────────────────── */
function selectFile(i) {
  const f = displayFiles[i];
  if (!f) return;
  selectedFile = f;

  document.querySelectorAll('.list-row').forEach(el => el.classList.remove('selected'));
  const lc = document.getElementById('fl-' + i);
  if (lc) lc.classList.add('selected');

  const acct = findAccountByFile(f);
  document.getElementById('rp-preview').textContent = f._icon;
  document.getElementById('rp-name').textContent    = f.name;
  document.getElementById('rp-svc').innerHTML =
    `<span style="color:${svcColor(f._svc)};font-weight:600">${svcLabel(f._svc)}</span>` +
    (acct ? ` <span style="color:#888;font-weight:400">— ${accountLabel(acct)}</span>` : '');
  document.getElementById('rp-size').textContent    = fmtSize(parseInt(f.size)||0);
  document.getElementById('rp-date').textContent    = fmtDateFull(f.modifiedTime);
  document.getElementById('rp-shared').textContent  = f.shared ? '👥 Partagé' : '🔒 Privé';

  openSheet('rp-sheet');
}

function clearSelection() {
  selectedFile = null;
  document.querySelectorAll('.list-row').forEach(el => el.classList.remove('selected'));
  closeSheet('rp-sheet');
}

/* ─── Storage Panel ──────────────────────────────────────────── */
function showStoragePanel() {
  clearSelection();
  openSheet('rp-storage-sheet');
  drawStorageDonut();
}
function closeStoragePanel() { closeSheet('rp-storage-sheet'); }

function drawStorageDonut() {
  const canvas = document.getElementById('storage-canvas');
  const ctx    = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height, cx = W/2, cy = H/2, R = 72, r = 46;

  const FREE_TINT = { gdrive: '#a5d6a7', onedrive: '#90caf9', dropbox: '#aec3ff' };
  const accts = allAccounts().filter(a => a.quota);

  const segments = [];
  accts.forEach(a => {
    const ut = acctUsedTotal(a);
    segments.push({ val: ut.used,          color: svcColor(a.svc) });
    segments.push({ val: ut.total - ut.used, color: FREE_TINT[a.svc] });
  });
  const filtered = segments.filter(s => s.val > 0);
  const sum = filtered.reduce((acc, s) => acc + s.val, 0) || 1;

  ctx.clearRect(0, 0, W, H);
  let angle = -Math.PI / 2;
  filtered.forEach(s => {
    const sweep = (s.val / sum) * 2 * Math.PI;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, R, angle, angle + sweep);
    ctx.closePath();
    ctx.fillStyle = s.color;
    ctx.fill();
    angle += sweep;
  });

  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, 2 * Math.PI);
  ctx.fillStyle = '#fff';
  ctx.fill();

  const totalUsed = accts.reduce((acc, a) => acc + acctUsedTotal(a).used, 0);
  const totalGo = Math.round(totalUsed / 1073741824 * 10) / 10;
  ctx.fillStyle = '#111';
  ctx.font = 'bold 15px Segoe UI';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(totalGo + ' Go', cx, cy);

  const legend = document.getElementById('storage-legend');
  legend.innerHTML = accts.map(a => {
    const ut = acctUsedTotal(a);
    return `
    <div style="display:flex;align-items:center;gap:7px;margin-bottom:7px">
      <div style="width:10px;height:10px;border-radius:50%;background:${svcColor(a.svc)};flex-shrink:0"></div>
      <div style="flex:1;font-size:11px;color:#444">${svcLabel(a.svc)} — ${accountLabel(a)}</div>
      <div style="font-size:10px;color:#888">${fmtSize(ut.used)} / ${fmtSize(ut.total)}</div>
    </div>`;
  }).join('') || '<div style="font-size:11px;color:#888">Connectez un compte pour voir son espace disque</div>';
}

/* ─── Actions ────────────────────────────────────────────────── */
async function getOrCreateDropboxLink(f) {
  const acct = findAccountByFile(f);
  if (!acct || !acct.token || acct.token === 'DEMO') return null;
  try {
    const r = await fetch('https://api.dropboxapi.com/2/sharing/create_shared_link_with_settings', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + acct.token, 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: f._path }),
    });
    const d = await r.json();
    if (d.url) return d.url;
    if (d.error?.['.tag'] === 'shared_link_already_exists') {
      const r2 = await fetch('https://api.dropboxapi.com/2/sharing/list_shared_links', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + acct.token, 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: f._path, direct_only: true }),
      });
      const d2 = await r2.json();
      return d2.links?.[0]?.url || null;
    }
  } catch (e) { /* fall through to null */ }
  return null;
}

async function doShare() {
  if (!selectedFile) return;
  const f = selectedFile;
  if (f._svc === 'dropbox' && !f.webViewLink) {
    toast('⏳ Création du lien de partage Dropbox…');
    const link = await getOrCreateDropboxLink(f);
    if (link) { openExternal(link); return; }
    toast('ℹ Lien non disponible (mode démo ou permission manquante)');
    return;
  }
  if (f.webViewLink && f.webViewLink !== '#') {
    openExternal(f.webViewLink);
  } else {
    toast('ℹ Lien de partage non disponible (mode démo)');
  }
}

async function doOpenWeb() {
  if (!selectedFile) return;
  const f = selectedFile;
  if (f._svc === 'dropbox' && !f.webViewLink) {
    toast('⏳ Ouverture depuis Dropbox…');
    const link = await getOrCreateDropboxLink(f);
    if (link) { openExternal(link); return; }
    toast('ℹ Lien non disponible (mode démo ou permission manquante)');
    return;
  }
  if (f.webViewLink && f.webViewLink !== '#') {
    openExternal(f.webViewLink);
  } else {
    toast('ℹ Lien non disponible en mode démo');
  }
}

async function doDownloadFile() {
  if (!selectedFile) return;
  const f = selectedFile;
  const acct = findAccountByFile(f);
  if (!acct) { toast('⚠ Compte introuvable'); return; }
  toast('⏳ Préparation du téléchargement de "' + f.name + '"…');

  if (f._svc === 'gdrive' && acct.token && acct.token !== 'DEMO') {
    let url;
    if (f.mimeType.startsWith('application/vnd.google-apps')) {
      const map = {
        'application/vnd.google-apps.document':     'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.google-apps.spreadsheet':  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.google-apps.presentation': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      };
      const exp = map[f.mimeType] || 'application/pdf';
      url = `https://www.googleapis.com/drive/v3/files/${f.id}/export?mimeType=${encodeURIComponent(exp)}`;
    } else {
      url = `https://www.googleapis.com/drive/v3/files/${f.id}?alt=media`;
    }
    if (window.electronAPI?.downloadFile) window.electronAPI.downloadFile(url, f.name, 'Bearer ' + acct.token);
    else openExternal(url);
  } else if (f._svc === 'onedrive' && acct.token && acct.token !== 'DEMO') {
    const r = await fetch(`https://graph.microsoft.com/v1.0/me/drive/items/${f.id}/content`,
      { headers: { Authorization: 'Bearer ' + acct.token }, redirect: 'manual' });
    const dlUrl = r.headers.get('Location') || r.url;
    if (window.electronAPI?.downloadFile) window.electronAPI.downloadFile(dlUrl, f.name, 'Bearer ' + acct.token);
    else openExternal(dlUrl);
  } else if (f._svc === 'dropbox' && acct.token && acct.token !== 'DEMO') {
    if (window.electronAPI?.downloadDropboxFile) {
      const res = await window.electronAPI.downloadDropboxFile(acct.token, f._path, f.name);
      if (res?.success) toast('✓ "' + f.name + '" téléchargé');
      else if (!res?.cancelled) toast('❌ ' + (res?.error || 'Échec du téléchargement Dropbox'));
    } else {
      toast('ℹ Téléchargement Dropbox nécessite l\'app desktop');
    }
  } else {
    toast('ℹ Téléchargement non disponible en mode démo');
  }
}

function doDelete() {
  if (!selectedFile) return;
  const f = selectedFile;
  const acct = findAccountByFile(f);
  if (!confirm(`Supprimer "${f.name}" de ${svcLabel(f._svc)} (${acct ? accountLabel(acct) : '?'}) ?`)) return;

  toast('⏳ Suppression en cours…');
  const deleteRemote = async () => {
    if (!acct || !acct.token || acct.token === 'DEMO') return;
    if (f._svc === 'gdrive') {
      await fetch(`https://www.googleapis.com/drive/v3/files/${f.id}`,
        { method: 'DELETE', headers: { Authorization: 'Bearer ' + acct.token } });
    } else if (f._svc === 'onedrive') {
      await fetch(`https://graph.microsoft.com/v1.0/me/drive/items/${f.id}`,
        { method: 'DELETE', headers: { Authorization: 'Bearer ' + acct.token } });
    } else if (f._svc === 'dropbox') {
      await fetch('https://api.dropboxapi.com/2/files/delete_v2', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + acct.token, 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: f._path }),
      });
    }
  };

  deleteRemote().finally(() => {
    if (acct) {
      const idx = acct.files.findIndex(x => x.id === f.id);
      if (idx > -1) acct.files.splice(idx, 1);
    }
    const ai = allFiles.findIndex(x => x.id === f.id && x._acct === f._acct);
    if (ai > -1) allFiles.splice(ai, 1);
    clearSelection();
    applyFiltersAndRender();
    toast('🗑 "' + f.name + '" supprimé');
  });
}

function doCopyToOther() {
  if (!selectedFile) return;
  const f = selectedFile;
  const others = allAccounts().filter(a => a.id !== f._acct);

  if (others.length === 0) {
    toast('⚠ Connectez un autre compte pour pouvoir copier ce fichier');
    return;
  }
  if (others.length > 1) {
    toast('ℹ Plusieurs comptes connectés — utilisez "Transfert inter-cloud" pour choisir la destination', 4000);
    openTransferModal();
    return;
  }

  const dest = others[0];
  toast('⏳ Copie de "' + f.name + '" vers ' + svcLabel(dest.svc) + ' (' + accountLabel(dest) + ')…');
  setTimeout(() => {
    const copy = { ...f, id: f.id + '_copy_' + Date.now(), _svc: dest.svc, _acct: dest.id };
    dest.files.unshift(copy);
    refreshAllFiles();
    toast('✓ "' + f.name + '" copié vers ' + svcLabel(dest.svc) + ' (' + accountLabel(dest) + ')');
  }, 1400);
}

/* ─── Transfer inter-cloud (now between individual ACCOUNTS) ─── */
function populateTransferSelects() {
  const accts = allAccounts();
  const opts = accts.map(a => `<option value="${a.id}">${svcLabel(a.svc)} — ${accountLabel(a)}</option>`).join('');
  document.getElementById('tr-src').innerHTML = opts;
  document.getElementById('tr-dst').innerHTML = opts;
  if (accts.length > 1) document.getElementById('tr-dst').selectedIndex = 1;
}

function openTransferModal() {
  if (allAccounts().length < 2) { toast('⚠ Connectez au moins 2 comptes pour transférer entre eux'); return; }
  populateTransferSelects();
  openModal('modal-transfer');
}

function startTransfer() {
  const srcId = document.getElementById('tr-src').value;
  const dstId = document.getElementById('tr-dst').value;
  if (srcId === dstId) { toast('⚠ Source et destination identiques'); return; }
  const src = allAccounts().find(a => a.id === srcId);
  const dst = allAccounts().find(a => a.id === dstId);
  if (!src || !dst) { toast('⚠ Compte introuvable'); return; }

  const prog   = document.getElementById('tr-progress');
  const bar    = document.getElementById('tr-bar');
  const status = document.getElementById('tr-status');
  prog.style.display = 'block';

  const steps = ['Analyse des fichiers…', 'Connexion établie…', 'Transfert en cours…', 'Vérification des données…', 'Terminé ✓'];
  let p = 0;
  const iv = setInterval(() => {
    p += 20;
    bar.style.width = p + '%';
    status.textContent = steps[Math.floor(p/20) - 1] || '';
    if (p >= 100) {
      clearInterval(iv);
      setTimeout(() => {
        closeModal('modal-transfer');
        toast('✓ Transfert terminé vers ' + svcLabel(dst.svc) + ' (' + accountLabel(dst) + ')');
      }, 500);
    }
  }, 600);
}

/* ─── Upload (destination is now a specific ACCOUNT) ──────────── */
function openUploadModal() {
  const accts = allAccounts();
  if (!accts.length) { toast('⚠ Connectez d\'abord un compte'); return; }
  document.getElementById('up-dst').innerHTML =
    accts.map(a => `<option value="${a.id}">${svcLabel(a.svc)} — ${accountLabel(a)}</option>`).join('');
  openModal('modal-upload');
}

function onFileSelect(input) {
  const files = input.files;
  if (!files.length) return;
  if (files.length === 1) {
    document.getElementById('up-label').textContent = files[0].name + ' · ' + fmtSize(files[0].size);
  } else {
    document.getElementById('up-label').textContent = files.length + ' fichiers sélectionnés';
  }
}

async function startUpload() {
  const dstId = document.getElementById('up-dst').value;
  const dst   = allAccounts().find(a => a.id === dstId);
  const path  = document.getElementById('up-path').value || '/';
  const files = document.getElementById('up-file').files;
  if (!dst) { toast('⚠ Compte introuvable'); return; }
  if (!files.length) { toast('⚠ Sélectionnez au moins un fichier'); return; }

  const prog   = document.getElementById('up-progress');
  const bar    = document.getElementById('up-bar');
  const status = document.getElementById('up-status');
  bar.style.background = svcColor(dst.svc);
  prog.style.display = 'block';

  for (let idx = 0; idx < files.length; idx++) {
    const file = files[idx];
    status.textContent = `Upload "${file.name}" (${idx+1}/${files.length})…`;

    await new Promise(resolve => {
      let p = 0;
      const iv = setInterval(() => {
        p += 12 + Math.random() * 10;
        bar.style.width = Math.min(p, 100) + '%';
        if (p >= 100) {
          clearInterval(iv);
          if (dst.svc === 'gdrive' && dst.token && dst.token !== 'DEMO') {
            const formData = new FormData();
            formData.append('metadata', new Blob([JSON.stringify({ name: file.name, parents: ['root'] })], { type: 'application/json' }));
            formData.append('file', file);
            fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
              method: 'POST', headers: { Authorization: 'Bearer ' + dst.token }, body: formData
            }).then(r => r.json()).then(data => {
              if (data.id) dst.files.unshift({ id:data.id, name:file.name, mimeType:file.type||'application/octet-stream', size:file.size.toString(), modifiedTime:new Date().toISOString(), owners:[{displayName:dst.user}], webViewLink:'#', shared:false, _svc:'gdrive', _acct:dst.id, _icon:getIcon(file.type||'') });
            }).finally(resolve);
          } else if (dst.svc === 'onedrive' && dst.token && dst.token !== 'DEMO') {
            fetch(`https://graph.microsoft.com/v1.0/me/drive/root:/${encodeURIComponent(file.name)}:/content`, {
              method: 'PUT', headers: { Authorization: 'Bearer ' + dst.token, 'Content-Type': file.type || 'application/octet-stream' }, body: file
            }).then(r => r.json()).then(data => {
              if (data.id) dst.files.unshift({ id:data.id, name:file.name, mimeType:file.type||'application/octet-stream', size:file.size.toString(), modifiedTime:new Date().toISOString(), owners:[{displayName:dst.user}], webViewLink:data.webUrl||'#', shared:false, _svc:'onedrive', _acct:dst.id, _icon:getIcon(file.type||'') });
            }).finally(resolve);
          } else if (dst.svc === 'dropbox' && dst.token && dst.token !== 'DEMO') {
            const folder = path.endsWith('/') ? path : path + '/';
            const targetPath = (folder === '/' ? '' : folder) + file.name;
            fetch('https://content.dropboxapi.com/2/files/upload', {
              method: 'POST',
              headers: { Authorization: 'Bearer ' + dst.token, 'Content-Type': 'application/octet-stream', 'Dropbox-API-Arg': JSON.stringify({ path: targetPath, mode: 'add', autorename: true, mute: false }) },
              body: file
            }).then(r => r.json()).then(data => {
              if (data.path_lower) dst.files.unshift({ id:data.id || data.path_lower, name:data.name || file.name, mimeType:guessMimeFromName(data.name||file.name), size:(data.size||file.size).toString(), modifiedTime:data.client_modified||new Date().toISOString(), owners:[{displayName:dst.user}], webViewLink:null, shared:false, _svc:'dropbox', _acct:dst.id, _icon:getIcon(guessMimeFromName(data.name||file.name)), _path:data.path_lower });
            }).finally(resolve);
          } else {
            // Demo mode: simulate
            dst.files.unshift({ id:'up_'+Date.now(), name:file.name, mimeType:file.type||'application/octet-stream', size:file.size.toString(), modifiedTime:new Date().toISOString(), owners:[{displayName:dst.user||'Vous'}], webViewLink:'#', shared:false, _svc:dst.svc, _acct:dst.id, _icon:getIcon(file.type||'') });
            resolve();
          }
        }
      }, 100);
    });
    bar.style.width = '0%';
  }

  setTimeout(() => {
    closeModal('modal-upload');
    document.getElementById('up-label').textContent = 'Cliquez ou glissez un fichier ici';
    document.getElementById('up-file').value = '';
    refreshAllFiles();
    toast('✓ ' + files.length + ' fichier' + (files.length>1?'s':'') + ' uploadé' + (files.length>1?'s':'') + ' vers ' + svcLabel(dst.svc) + ' (' + accountLabel(dst) + ')');
  }, 300);
}

/* ─── Nav / View controls ─────────────────────────────────────── */
function setNav(el, view) {
  currentNav = view;
  document.querySelectorAll('.nav-item, .acct-row').forEach(x => x.classList.remove('active'));
  if (el) el.classList.add('active');

  const labels = { all:'Mes documents', recent:'Récents', shared:'Partagés', starred:'Favoris', gdrive:'Google Drive', onedrive:'OneDrive', dropbox:'Dropbox' };
  let bcText = labels[view];
  if (!bcText) {
    const acc = allAccounts().find(a => a.id === view);
    bcText = acc ? (svcLabel(acc.svc) + ' — ' + accountLabel(acc)) : view;
  }
  document.getElementById('bc-current').textContent = bcText;
  renderSidebarAccounts(); // reflect the active account row
  applyFiltersAndRender();
}

function setTab(el, tab) {
  currentTab = tab;
  document.querySelectorAll('.ftab').forEach(x => x.classList.remove('active'));
  el.classList.add('active');
  applyFiltersAndRender();
}

function setChip(el, chip) {
  currentChip = chip;
  document.querySelectorAll('.chip').forEach(x => x.classList.remove('active'));
  el.classList.add('active');
  applyFiltersAndRender();
}

function doSearch() { applyFiltersAndRender(); }

function sortBy(field) {
  if (sortField === field) sortAsc = !sortAsc;
  else { sortField = field; sortAsc = true; }
  applyFiltersAndRender();
}

async function doRefresh() {
  const btn = document.getElementById('btn-refresh');
  btn.style.transform = 'rotate(360deg)';
  btn.style.transition = 'transform .6s';
  setTimeout(() => { btn.style.transition = 'none'; btn.style.transform = ''; }, 650);

  let refreshed = false;
  for (const acct of allAccounts()) {
    if (!acct.token || acct.token === 'DEMO') continue;
    refreshed = true;
    if (acct.svc === 'gdrive') { await fetchGDriveFiles(acct); }
    else if (acct.svc === 'onedrive') { acct.files = []; await fetchOneDriveFiles(acct); }
    else if (acct.svc === 'dropbox') { acct.files = []; await fetchDropboxFiles(acct); }
  }
  if (refreshed) { refreshAllFiles(); toast('✓ Actualisation terminée'); }
  else if (allFiles.length) { toast('ℹ Mode démo — actualisation simulée'); }
  else toast('⚠ Aucun compte connecté');
}

/* ─── Service Tab Switch (in the connect modal) ───────────────── */
function switchServiceTab(el, tab) {
  document.querySelectorAll('.stab').forEach(x => x.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('tab-gd').style.display = tab === 'gd' ? 'block' : 'none';
  document.getElementById('tab-od').style.display = tab === 'od' ? 'block' : 'none';
  document.getElementById('tab-db').style.display = tab === 'db' ? 'block' : 'none';
}

/* ─── Modal overlay click-outside ───────────────────────────── */
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) overlay.classList.remove('open');
  });
});

/* ─── Mobile UI helpers: drawer, search bar, bottom sheets ────── */
function toggleDrawer(open) {
  document.getElementById('drawer').classList.toggle('open', open);
  document.getElementById('drawer-overlay').classList.toggle('show', open);
}
function toggleSearch() {
  const wrap = document.getElementById('search-wrap');
  const showing = wrap.classList.toggle('show');
  wrap.classList.toggle('hidden', !showing);
  if (showing) setTimeout(() => document.getElementById('search-input').focus(), 150);
  else { document.getElementById('search-input').value = ''; doSearch(); }
}
function openSheet(id) {
  document.getElementById(id).classList.add('open');
  document.getElementById('sheet-overlay').classList.add('show');
}
function closeSheet(id) {
  document.getElementById(id).classList.remove('open');
  document.getElementById('sheet-overlay').classList.remove('show');
}

// Hardware/gesture back button (Android): close whatever is open, in order,
// instead of exiting the app immediately.
if (window.Capacitor?.Plugins?.App) {
  window.Capacitor.Plugins.App.addListener('backButton', () => {
    const openModalEl = document.querySelector('.modal-overlay.open');
    if (openModalEl) { openModalEl.classList.remove('open'); return; }
    if (document.getElementById('rp-sheet').classList.contains('open')) { clearSelection(); return; }
    if (document.getElementById('rp-storage-sheet').classList.contains('open')) { closeStoragePanel(); return; }
    if (document.getElementById('drawer').classList.contains('open')) { toggleDrawer(false); return; }
    window.Capacitor.Plugins.App.exitApp();
  });
}

/* ─── Init ───────────────────────────────────────────────────── */
updateConnCount();
renderSidebarAccounts();
console.log('CloudUnify Pro (Android) démarré — Version 2.0.0 (multi-compte)');
