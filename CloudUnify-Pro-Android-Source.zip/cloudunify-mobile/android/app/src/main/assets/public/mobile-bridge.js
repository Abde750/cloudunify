/* ═══════════════════════════════════════════════════════════════
   mobile-bridge.js
   Provides the SAME window.electronAPI surface that app.js already
   calls on desktop, but backed by Capacitor plugins instead of
   Electron IPC. This lets app.js's account/API logic (identical
   across all 3 services) run UNCHANGED on Android.

   Key difference from desktop: there is no local HTTP server for
   OAuth here — mobile apps can't rely on a redirect back to
   http://127.0.0.1:PORT the way a desktop process can. Instead we
   use a custom URL scheme (cloudunify://oauth-callback) registered
   in AndroidManifest.xml; Google/Microsoft/Dropbox redirect to it,
   Android hands control back to this app, and Capacitor's App
   plugin fires 'appUrlOpen' with that URL so we can read ?code=...
═══════════════════════════════════════════════════════════════ */
(function () {
  const { Capacitor } = window;
  const { App }        = window.Capacitor?.Plugins || {};
  const { Browser }     = window.Capacitor?.Plugins || {};
  const { Filesystem, Directory } = window.Capacitor?.Plugins || {};
  const { Share }       = window.Capacitor?.Plugins || {};

  const REDIRECT_URI = 'cloudunify://oauth-callback';

  /* ─── PKCE via Web Crypto (SubtleCrypto — no Node 'crypto' on mobile) ─── */
  function base64url(buf) {
    let str = '';
    const bytes = new Uint8Array(buf);
    for (let i = 0; i < bytes.length; i++) str += String.fromCharCode(bytes[i]);
    return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function randomVerifier() {
    const arr = new Uint8Array(32);
    crypto.getRandomValues(arr);
    return base64url(arr.buffer);
  }
  async function generatePKCE() {
    const verifier = randomVerifier();
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier));
    return { verifier, challenge: base64url(digest) };
  }

  /* ─── Token exchange (same endpoints/params as the desktop main.js) ─── */
  async function exchangeCode(service, code, verifier, clientId, clientSecret) {
    let url, params;
    if (service === 'gdrive') {
      url = 'https://oauth2.googleapis.com/token';
      params = { client_id: clientId, client_secret: clientSecret || '', code, code_verifier: verifier, grant_type: 'authorization_code', redirect_uri: REDIRECT_URI };
    } else if (service === 'onedrive') {
      url = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
      params = { client_id: clientId, code, code_verifier: verifier, grant_type: 'authorization_code', redirect_uri: REDIRECT_URI, scope: 'Files.ReadWrite.All User.Read offline_access' };
    } else {
      url = 'https://api.dropbox.com/oauth2/token';
      params = { client_id: clientId, code, code_verifier: verifier, grant_type: 'authorization_code', redirect_uri: REDIRECT_URI };
    }
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(params).toString(),
    });
    const json = await res.json().catch(() => null);
    if (!res.ok || !json?.access_token) {
      throw new Error(json?.error_description || json?.error || ('HTTP ' + res.status));
    }
    return json;
  }

  function buildAuthUrl(service, clientId, challenge) {
    if (service === 'gdrive') {
      return 'https://accounts.google.com/o/oauth2/v2/auth'
        + '?client_id=' + encodeURIComponent(clientId)
        + '&redirect_uri=' + encodeURIComponent(REDIRECT_URI)
        + '&response_type=code'
        + '&scope=' + encodeURIComponent('https://www.googleapis.com/auth/drive https://www.googleapis.com/auth/userinfo.profile')
        + '&access_type=offline&prompt=consent'
        + '&code_challenge=' + challenge + '&code_challenge_method=S256';
    }
    if (service === 'onedrive') {
      return 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize'
        + '?client_id=' + encodeURIComponent(clientId)
        + '&redirect_uri=' + encodeURIComponent(REDIRECT_URI)
        + '&response_type=code'
        + '&scope=' + encodeURIComponent('Files.ReadWrite.All User.Read offline_access')
        + '&prompt=select_account'
        + '&code_challenge=' + challenge + '&code_challenge_method=S256';
    }
    return 'https://www.dropbox.com/oauth2/authorize'
      + '?client_id=' + encodeURIComponent(clientId)
      + '&redirect_uri=' + encodeURIComponent(REDIRECT_URI)
      + '&response_type=code&token_access_type=offline'
      + '&scope=' + encodeURIComponent('account_info.read files.metadata.read files.content.read files.content.write sharing.read sharing.write')
      + '&code_challenge=' + challenge + '&code_challenge_method=S256';
  }

  /* One OAuth flow at a time — resolved by the appUrlOpen listener below */
  let pendingOAuth = null;

  async function startOAuth(service, clientId, clientSecret) {
    if (!Browser || !App) {
      return { error: 'Plugins Capacitor indisponibles (build incomplet)' };
    }
    const { verifier, challenge } = await generatePKCE();
    const authUrl = buildAuthUrl(service, clientId, challenge);

    return new Promise((resolve) => {
      let settled = false;
      const finish = (result) => {
        if (settled) return;
        settled = true;
        pendingOAuth = null;
        try { Browser.close(); } catch (e) { /* already closed */ }
        resolve(result);
      };

      pendingOAuth = { service, verifier, clientId, clientSecret, finish };

      // Safety net: give up after 5 minutes if the user never comes back.
      setTimeout(() => finish({ error: 'Délai dépassé (5 min) — réessayez.' }), 5 * 60 * 1000);

      Browser.open({ url: authUrl, presentationStyle: 'popover' }).catch((e) => {
        finish({ error: 'Impossible d\'ouvrir le navigateur : ' + e.message });
      });
    });
  }

  // Fired by Android when cloudunify://oauth-callback is opened (registered
  // in AndroidManifest.xml). This is the mobile equivalent of the desktop's
  // local HTTP server catching the loopback redirect.
  if (App) {
    App.addListener('appUrlOpen', async (data) => {
      if (!pendingOAuth) return;
      const { service, verifier, clientId, clientSecret, finish } = pendingOAuth;
      try {
        const u = new URL(data.url);
        if (!data.url.startsWith(REDIRECT_URI)) return; // not our redirect
        const code  = u.searchParams.get('code');
        const error = u.searchParams.get('error');
        if (error) { finish({ error: 'Autorisation refusée par le fournisseur : ' + error }); return; }
        if (!code) { finish({ error: 'Aucun code d\'autorisation reçu' }); return; }
        const tokenResp = await exchangeCode(service, code, verifier, clientId, clientSecret);
        finish({ token: tokenResp.access_token, refreshToken: tokenResp.refresh_token, expiresIn: tokenResp.expires_in });
      } catch (e) {
        finish({ error: 'Échange du code échoué : ' + e.message });
      }
    });
  }

  /* ─── Downloads: fetch → device storage → share/open sheet ─────────── */
  async function saveBlobToDevice(blob, fileName) {
    const b64 = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result.split(',')[1]);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
    const write = await Filesystem.writeFile({ path: fileName, data: b64, directory: Directory.Documents });
    try { await Share.share({ title: fileName, url: write.uri }); } catch (e) { /* share sheet dismissed — file is still saved */ }
    return write.uri;
  }

  async function downloadFile(url, fileName, authHeader) {
    try {
      const res = await fetch(url, { headers: authHeader ? { Authorization: authHeader } : {} });
      if (!res.ok) return { error: 'HTTP ' + res.status };
      const blob = await res.blob();
      const uri = await saveBlobToDevice(blob, fileName);
      return { success: true, path: uri };
    } catch (e) { return { error: e.message }; }
  }

  async function downloadDropboxFile(token, dropboxPath, fileName) {
    try {
      const res = await fetch('https://content.dropboxapi.com/2/files/download', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + token, 'Dropbox-API-Arg': JSON.stringify({ path: dropboxPath }) },
      });
      if (!res.ok) {
        const errBody = await res.text().catch(() => '');
        let msg = 'HTTP ' + res.status;
        try { msg = JSON.parse(errBody).error_summary || msg; } catch (e) { /* keep default */ }
        return { error: msg };
      }
      const blob = await res.blob();
      const uri = await saveBlobToDevice(blob, fileName);
      return { success: true, path: uri };
    } catch (e) { return { error: e.message }; }
  }

  /* ─── window.electronAPI shim — same surface app.js already calls ──── */
  window.electronAPI = {
    minimize: () => {}, maximize: () => {}, close: () => {}, // no title bar on mobile
    openExternal: (url) => Browser ? Browser.open({ url }) : window.open(url, '_blank'),
    downloadFile, downloadDropboxFile, startOAuth,
  };

  window.__isMobile = true;
})();
